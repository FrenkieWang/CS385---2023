export const products = [{
  "pid": 11,
  "type": "Vegetable",
  "plant": {
    "name": "Savoy Cabbage seeds",
    "price": 3.5
  }
}, {
  "pid": 21,
  "type": "Fruit",
  "plant": {
    "name": "Brambley Apple Tree",
    "price": 35.0
  }
},
 {
  "pid": 211,
  "type": "Fruit",
  "plant": {
    "name": "Conference Pear Tree",
    "price": 35.0
  }
},
 {
  "pid": 121,
  "type": "Vegetable",
  "plant": {
    "name": "Tall Sweetcorn Seeds",
    "price": 4.5
  }
},
 {
  "pid": 88,
  "type": "Flowers",
  "plant": {
    "name": "Dahlia Bubls (10)",
    "price": 10.00
  }
},
 {
  "pid": 188,
  "type": "Flowers",
  "plant": {
    "name": "David Austin Rose",
    "price": 20.00
  }
}
];
