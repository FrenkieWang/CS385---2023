export const inventory = [
  {
    pid: 11,
    productCategory: "Vegetables",
    plant: {
      name: "Savoy Cabbage seeds",
      price: 3.5
    }
  },
  {
    pid: 21,
    productCategory: "Fruits",
    plant: {
      name: "Brambley Apple Tree",
      price: 35.0
    }
  },
  {
    pid: 211,
    productCategory: "Fruits",
    plant: {
      name: "Conference Pear Tree",
      price: 35.0
    }
  },
  {
    pid: 121,
    productCategory: "Vegetables",
    plant: {
      name: "Tall Sweetcorn Seeds",
      price: 4.5
    }
  },
  {
    pid: 88,
    productCategory: "Flowers",
    plant: {
      name: "Dahlia Bulbs (10)",
      price: 10.0
    }
  },
  {
    pid: 188,
    productCategory: "Flowers",
    plant: {
      name: "David Austin Rose",
      price: 20.0
    }
  },
  {
    pid: 288,
    productCategory: "Flowers",
    plant: {
      name: "Royal Red Tulips",
      price: 25.0
    }
  },
  {
    pid: 237,
    productCategory: "Vegetables",
    plant: {
      name: "Pumpkin Seeds",
      price: 5.5
    }
  }
];
